# Decimal Binary Converter 
A simple PYthon package to convert decimal numbers to binary and vice versa.


# Installation 
pip install decimal_binary converter